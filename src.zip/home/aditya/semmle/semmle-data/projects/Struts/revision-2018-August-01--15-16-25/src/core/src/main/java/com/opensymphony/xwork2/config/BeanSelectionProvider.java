package com.opensymphony.xwork2.config;

/**
 * When implemented allows to alias already existing beans
 */
public interface BeanSelectionProvider extends ConfigurationProvider {

}
